$(document).ready(function(){
    
    //Sticky Menu
    $(".js--services-section").waypoint(function(direction){
        if(direction =="down"){
            $("nav").addClass("sticky");
           }else{
            $("nav").removeClass("sticky");
           }
    });
    

    
    
    //Mixitup (portfolio section)
    var mixer = mixitup('.container');
    
    //Smooth Scroll IE/EDGE/SAFARI
    
    
});

function openNav(){
    document.getElementById("myNav").style.width="100%";
}

function closeNav(){
    document.getElementById("myNav").style.width="0%";
}