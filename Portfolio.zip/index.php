<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial scale=1.0">
    <meta http-equiv="X-UA-compatible" content="IE=edge">
    <title>MA Tareq single page portfolio Page</title>
    <link rel="shortcut icon" type="image/x-icon" href="resources/img/MA-logo.png">
    <!---- Google Fonts  ---->
    <link href="https://fonts.googleapis.com/css2?family=Titillium+Web:ital,wght@0,300;0,400;0,600;0,700;1,400&display=swap" rel="stylesheet">
    <!---- Font Awesome  ---->
    <script src="https://kit.fontawesome.com/f843c3425d.js" crossorigin="anonymous"></script>
    <!---- Vendors File ---->
    <link rel="stylesheet" href="vendors/css/normalize.css">
    <link rel="stylesheet" href="vendors/css/grid.css">
    <!---- Resources File  ---->
    <link rel="stylesheet" href="vendors/css/animated-circle.css">
    <link rel="stylesheet" href="resources/css/style.css">
    <link rel="stylesheet" href="resources/css/responsive.css">
</head>
<body>
    
    <!---- Start Header Section ---->
    <header id="home">
        <nav>
            <div class="row">
                <a href="#home">
                    <img src="resources/img/MA-logo.png" alt="MA" class="logo">
                </a>
                <ul class="main-nav">
                    <li class="active"><a href="#home">Home</a></li>
                    <li><a href="#service">Service</a></li>
                    <li><a href="#team">Team</a></li>
                    <li><a href="#skill">Skill</a></li>
                    <li><a href="#portfolio">Portfolio</a></li>
                    <li><a href="#testimonial">Testimonial</a></li>
                    <li><a href="#contact">Contact</a></li>
                </ul>
                <div class="mobile-menu">
                    <span style="color: #fff;" onclick="openNav()"><i class="fas fa-bars"></i></span>
                    <div id="myNav" class="overlay">
                        <a href="javascript:void(0)" onclick="closeNav()" class="closebtn">&times;</a>
                 <div class="overlay-content">
                     <a onclick="closeNav()" href="#home">Home</a>
                     <a onclick="closeNav()" href="#service">Service</a>
                     <a onclick="closeNav()" href="#team">Team</a>
                     <a onclick="closeNav()" href="#skill">Skill</a>
                     <a onclick="closeNav()" href="#portfolio">Portfolio</a>
                     <a onclick="closeNav()" href="#testimonial">Testimonial</a>
                     <a onclick="closeNav()" href="#contact">Contact</a>
                 </div>
                    </div>
                </div>
            </div>
        </nav>
        <div class="row">
            <div class="hero-text-box">
                <h1>Hi there! This is Mujahidul Amin. I am an web designer 
                    and I design awesome websites.
                </h1>
                <a href="#" class="btn btn-hero">Work with me</a>
            </div>
        </div>
    </header>
    
    <!---- End Header Section ---->
    
    
    <!---- Start Services Section ---->
    
    <section class="services-section js--services-section" id="service">
        <div class="row">
            <h2>SERVICES WE PROVIDE</h2>
            <p class="little-description">We are working with both individuals and businesses from all over the globe to create awesome websites and applications.
            </p>
        </div>
        <div class="row">
            <div class="col span_1_of_4 box">
                <img src="resources/img/flag..png" alt="flag" class="services-icon" >
                <h3>Branding</h3>
                <p>Lorem ipsum dolor sit amet,consectetuer adipiscing elit, sed diam nonummy nibh.
                </p>
            </div>
            <div class="col span_1_of_4 box">
                <img src="resources/img/pencil.png" alt="pencil" class="services-icon">
                <h3>Design</h3>
                <p>Sed ut perspiciatis unde omnis iste natus     error sit voluptatem lorem ipsum
                </p>
            </div>
            <div class="col span_1_of_4 box">
                <img src="resources/img/setting.png" alt="setting" class="services-icon">
                <h3>Development</h3>
                <p>At vero eos et accusamus et iusto odio dignissimos qui blanditiis praesentium.
                </p>
            </div>
            <div class="col span_1_of_4 box">
                <img src="resources/img/rocket.png" alt="rocket" class="services-icon">
                <h3>ROCKET SCIENCE</h3>
                <p>Et harum quidem rerum est et expedita distinctio. Nam libero tempore.
                </p>
            </div>
        </div>
    </section>
    
    <!---- End Services Section ---->
    
    <!---- Start Team Section ---->
    
    <section class="team-section" id="team">
        <div class="row">
            <h2>MEET MY BEAUTIFUL TEAM</h2>
            <p class="little-description">I have a small team of designers and developers, who help brands with big ideas.</p>
        </div>
        <div class="row">
            <div class="col span_1_of_4 box">
            <img src="resources/img/tareq.jpg" alt="tareq" class="team-member">
            <h3>Mujahidul Amin</h3>
            <span class="rol">CEO / MA</span>
            <p>Lorem ipsum dolor sit amet, 
               consectetuer adipiscing elit, sed diam nonummy nibh euismod tincidunt ut laoreet dolore magna.
            </p>
            <div class="social-link">
                <ul>
                    <li><a href="https://www.facebook.com/mujahidul.amin/" target="_blank"><i class="fab fa-facebook-f"></i></a></li>
                    <li><a href="#"><i class="fab fa-twitter"></i></a></li>
                    <li><a href="#"><i class="fab fa-linkedin-in"></i></a></li>
                    <li><a href="#"><i class="fas fa-envelope"></i></a></li>
                </ul>
            </div>
        </div>
        <div class="col span_1_of_4 box">
            <img src="resources/img/tammim.jpg" alt="tammim" class="team-member">
            <h3>Mazbaul Hoque</h3>
            <span class="rol">Lead Designer</span>
            <p>Lorem ipsum dolor sit amet, 
               consectetuer adipiscing elit, sed diam nonummy nibh euismod tincidunt ut laoreet dolore magna.
            </p>
            <div class="social-link">
                <ul>
                    <li><a href="https://www.facebook.com/mazbaulhoque.tammim" target="_blank"><i class="fab fa-facebook-f"></i></a></li>
                    <li><a href="#"><i class="fab fa-twitter"></i></a></li>
                    <li><a href="#"><i class="fab fa-linkedin-in"></i></a></li>
                    <li><a href="#"><i class="fas fa-envelope"></i></a></li>
                </ul>
            </div>
        </div>
        
        <div class="col span_1_of_4 box">
            <img src="resources/img/tareq.jpg" alt="tareq" class="team-member">
            <h3>Mujahidul Amin</h3>
            <span class="rol">CEO / MA</span>
            <p>Lorem ipsum dolor sit amet, 
               consectetuer adipiscing elit, sed diam nonummy nibh euismod tincidunt ut laoreet dolore magna.
            </p>
            <div class="social-link">
                <ul>
                    <li><a href="#"><i class="fab fa-facebook-f"></i></a></li>
                    <li><a href="#"><i class="fab fa-twitter"></i></a></li>
                    <li><a href="#"><i class="fab fa-linkedin-in"></i></a></li>
                    <li><a href="#"><i class="fas fa-envelope"></i></a></li>
                </ul>
            </div>
        </div>
        
        <div class="col span_1_of_4 box">
            <img src="resources/img/tammim.jpg" alt="tareq" class="team-member">
            <h3>Mazbaul Hoque</h3>
            <span class="rol">Lead Designer</span>
            <p>Lorem ipsum dolor sit amet, 
               consectetuer adipiscing elit, sed diam nonummy nibh euismod tincidunt ut laoreet dolore magna.
            </p>
            <div class="social-link">
                <ul>
                    <li><a href="#"><i class="fab fa-facebook-f"></i></a></li>
                    <li><a href="#"><i class="fab fa-twitter"></i></a></li>
                    <li><a href="#"><i class="fas fa-envelope"></i></a></li>
                </ul>
            </div>
        </div>
        </div>
    </section>
    
    
    <!---- End Team Section ---->
    
    <!---- Start Skill Section ---->
    
    <section class="skill-section" id="skill">
        <div class="row">
            <h2>WE GOT SKILLS!</h2>
            <p class="little-description">Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua.
            </p>
        </div>
        <div class="row">
            <div class="col span_1_of_4 box">
                <svg class="radial-progress web-design" data-percentage="90" viewBox="0 0 80 80">
                    <circle class="incomplete" cx="40" cy="40" r="35"></circle>
                    <circle class="complete" cx="40" cy="40" r="35" style="stroke-dashoffset:     39.58406743523136;"></circle>
                    <text class="percentage" x="50%" y="57%" transform="matrix(0, 1, -1, 0, 80, 0)">90%</text>
                </svg>
                <h3>Web Design</h3>
            </div>
            <div class="col span_1_of_4 box">
                <svg class="radial-progress html-css" data-percentage="75" viewBox="0 0 80 80">
                    <circle class="incomplete" cx="40" cy="40" r="35"></circle>
                    <circle class="complete" cx="40" cy="40" r="35" style="stroke-dashoffset:     39.58406743523136;"></circle>
                    <text class="percentage" x="50%" y="57%" transform="matrix(0, 1, -1, 0, 80, 0)">75%</text>
                </svg>
                <h3>HTML/CSS</h3>
            </div>
            <div class="col span_1_of_4 box">
                <svg class="radial-progress Graphic-design" data-percentage="70" viewBox="0 0 80 80">
                    <circle class="incomplete" cx="40" cy="40" r="35"></circle>
                    <circle class="complete" cx="40" cy="40" r="35" style="stroke-dashoffset:     39.58406743523136;"></circle>
                    <text class="percentage" x="50%" y="57%" transform="matrix(0, 1, -1, 0, 80, 0)">70%</text>
                </svg>
                <h3>Graphic Design</h3>
            </div>
            <div class="col span_1_of_4 box">
                <svg class="radial-progress Ui-Ux" data-percentage="85" viewBox="0 0 80 80">
                    <circle class="incomplete" cx="40" cy="40" r="35"></circle>
                    <circle class="complete" cx="40" cy="40" r="35" style="stroke-dashoffset:     39.58406743523136;"></circle>
                    <text class="percentage" x="50%" y="57%" transform="matrix(0, 1, -1, 0, 80, 0)">85%</text>
                </svg>
                <h3>Ui/UX</h3>
            </div>
        </div>
    </section>
    
    
    <!---- End Skill Section ---->
    
     <!---- Start Portfo Section ---->
     
     <section class="portfolio-section clr" id="portfolio">
         <div class="row">
             <h2>OUR PORTFOLIO</h2>
             <p class="little-description">Neque porro quisquam est, qui dolorem ipsum quia dolor sit amet consectetur, adipisci velit, sed quia non numquam
             </p>
         </div>
         <div class="row">
             <div class="portfolio-filter">
                 <button type="button" data-filter="all">all</button>
                 <button type="button" data-filter=".web">web</button>
                 <button type="button" data-filter=".apps">apps</button>
                 <button type="button" data-filter=".icons">icons</button>
             </div>
         </div>
         <div class="row container">
             <div class="col span_1_of_2 mix apps box">
                 <img src="resources/img/C-1.png" alt="cpmputer-1" class="portfolio-image">
                 <h4>Isometric Perspective Mock-Up</h4>
             </div>
             <div class="col span_1_of_2 mix apps web box">
                 <img src="resources/img/C-2.png" alt="cpmputer-2" class="portfolio-image">
                 <h4>Isometric Perspective Mock-Up</h4>
             </div>
             <div class="col span_1_of_2 mix icons box">
                 <img src="resources/img/C-3.png" alt="cpmputer-3" class="portfolio-image">
                 <h4>Isometric Perspective Mock-Up</h4>
             </div>
             <div class="col span_1_of_2 mix icons web apps box">
                 <img src="resources/img/C-4.png" alt="cpmputer-4" class="portfolio-image">
                 <h4>Isometric Perspective Mock-Up</h4>
             </div>
         </div>
         <!---
         <div class="row">
             <a href="" class="btn btn-load-more">load more project</a>
         </div>
         --->
     </section>
     
     <!---- End Portfolio Section ---->
     
     <!---- Start Testimonial Section ---->
     
       <section class="testimonial" id="testimonial">
           <div class="row">
               <h2>WHAT POEPLE SAY ABOUT US</h2>
               <p class="little-description">
                    Our clients love us!
               </p>
           </div>
           <div class="row">
               <div class="col span_1_of_2 box">
                   <div class="client-photo">
                       <img src="resources/img/tareq.jpg" alt="client-photo">
                   </div>
                   <div class="client-review">
                       <p>“Nullam dapibus blandit orci, viverra gravida dui lobortis eget. Maecenas fringilla urna eu nisl scelerisque.”</p>
                       <h3>Chanel Iman</h3>
                       <span class="role">CEO of Pinterest</span>
                   </div>
               </div>
               <div class="col span_1_of_2 box">
                   <div class="client-photo">
                       <img src="resources/img/tammim.jpg" alt="client-photo">
                   </div>
                   <div class="client-review">
                       <p>“Nullam dapibus blandit orci, viverra gravida dui lobortis eget. Maecenas fringilla urna eu nisl scelerisque.”</p>
                       <h3>Chanel Iman</h3>
                       <span class="role">CEO of Pinterest</span>
                   </div>
               </div>
               <div class="col span_1_of_2 box">
                   <div class="client-photo">
                       <img src="resources/img/tareq.jpg" alt="client-photo">
                   </div>
                   <div class="client-review">
                       <p>“Nullam dapibus blandit orci, viverra gravida dui lobortis eget. Maecenas fringilla urna eu nisl scelerisque.”</p>
                       <h3>Chanel Iman</h3>
                       <span class="role">CEO of Pinterest</span>
                   </div>
               </div>
               <div class="col span_1_of_2 box">
                   <div class="client-photo">
                       <img src="resources/img/tammim.jpg" alt="client-photo">
                   </div>
                   <div class="client-review">
                       <p>“Nullam dapibus blandit orci, viverra gravida dui lobortis eget. Maecenas fringilla urna eu nisl scelerisque.”</p>
                       <h3>Chanel Iman</h3>
                       <span class="role">CEO of Pinterest</span>
                   </div>
               </div>
           </div>
       </section>
        
     <!---- End Testomonial Section ---->
     
     
     <!---- Start Contact Section ---->
     <section class="contact-section" id="contact">
         <div class="row">
             <h2>GET IN TOUCH</h2>
             <p class="little-description">
                 1600 Pennsylvania Ave NW, Washington, DC 20500, United States of America. Tel: (202) 456-1111
             </p>
         </div>
         <div class="row">
             <form action="https://formspree.io/mujahidulamin1108152@gmail.com" method="post">
                 <div class="row">
                     <div class="col span_1_of_2 ">
                         <input type="text" name="Name" placeholder="Your Name *" required>
                     </div>
                     <div class="col span_1_of_2">
                         <input type="email" name="Email" placeholder="Your Email *" required>
                     </div>
                 </div>
                 <div class="row">
                     <textarea name="Massage" id="" cols="30" rows="10" placeholder="Your Massage *" required></textarea>
                 </div>
                 <div class="row">
                     <input type="submit" value="SEND MASSAGE" class="btn btn-submit">
                 </div>
             </form>
         </div>
     </section>
     
     <!---- End Contact Section ---->
     
     
     <!---- Start Footer Section ---->
     
     <section class="footer-section">
         <div class="row">
             <ul>
                 <li><a href="#">facebook</a></li>
                 <li><a href="#">twitter</a></li>
                 <li><a href="#">google+</a></li>
                 <li><a href="#">linkedin</a></li>
                 <li><a href="#">behance</a></li>
                 <li><a href="#">deribble</a></li>
                 <li><a href="#">github</a></li>
             </ul>
         </div>
     </section>
     
     <!---- End Footer Section ---->
    
    
    
     <!---- Java Script File ---->
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>
    <script src="vendors/js/html5shiv.min.js"></script>
    <script src="vendors/js/respond.min.js"></script>
    <script src="vendors/js/selectivizr.min.js"></script>
    <script src="vendors/js/jquery.waypoints.min.js"></script>
    <script src="vendors/js/animated-circule.js"></script>
    <script src="vendors/js/mixitup.min.js"></script>
    <script src="resources/js/main.js"></script>
</body>
</html>